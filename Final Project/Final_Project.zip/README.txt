=====================================
* Harjot Mangat                     *
* EECS 269 - Reinforcement Learning *
* Final Project - Racetrack         *
* Final_Project_Racetrack.py        *
=====================================

*This program was written in python3
*This program uses the following imports:
	numpy
	matplotlib
	racetrack

*tf_agents version 0.13.0

*The program implements the pseudocode for Tabular Dyna-Q for the racetrack environment given.

*The program will output the graph of rewards per episode. A graph will be saved to disk in a .png format of the graph shown on screen. The name of the graph will be something like 'Dyna-Q_racetrack.png'.

*This program requires no commnad line inputs, so it can be run from a terminal or command line with a call to the python interpreter and the name of the file. Such as "python Final_Project_Racetrack.py". 
